import React from "react";

import { useState } from "react";

export default function App(){
  const [message,setmessage]=useState("");
  const [messageList,setmessageList]=useState([]);
  const processmessage=(e)=>{
   setmessage(e.target.value);
  }
  const handlesend=()=>{
    const newList=[message,...messageList];
    setmessageList(newList);
    setmessage("");
  }

  return 
  /*
  <div>
    <header className="bg-dark text-light p-3 m-3">
    MyChatApp by(swati sarvade)(210940320127)
    </header>

    <div>
    <input className="form-control mt-2" type="text" value={message} placeholder="Lets chat here..." onChange={processmessage}/>
  <input className="btn btn-primary mt-2" type="button" value="SEND" onClick={handlesend}/>
    </div>
    {messageList.map((item,index)=>(
   <div className="bg-secondary bg-opacity-25 mt-1" key={index}>
     {item}
     </div>
    ))}
  </div>
}
*/

  
  (
    <>
    <Mycomponent/>
    <WhatsApp/>
    </>
  );
  }

function Mycomponent(){
  return(
    <div>
  <div className="bg-dark text-light p-3 m-3">
<div>
  MyChatApp by(swati sarvade)(210940320127)
</div>
  </div>
  </div>
  );
}
function WhatsApp(){
  return(
    
    <div className="">
  <input className="m-3 p-3" type="text" value="message" placeholder="Lets chat here..."/>
  <input className="p-3" type="button" value="SEND" />
  </div>
  
  );
}

